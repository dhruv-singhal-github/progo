import 'package:flutter/material.dart';

import 'package:firebase_core/firebase_core.dart';
class projectManagerScreen extends StatefulWidget {
  @override
  _projectManagerScreenState createState() => _projectManagerScreenState();
}

class _projectManagerScreenState extends State<projectManagerScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Text("hello"),
    );
  }
}
